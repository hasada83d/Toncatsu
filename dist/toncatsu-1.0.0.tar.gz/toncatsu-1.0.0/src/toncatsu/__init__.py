# -*- coding: utf-8 -*-
"""
Created on Wed May 28 10:22:48 2025

@author: hasada83d
"""

from .toncatsu import toncatsu